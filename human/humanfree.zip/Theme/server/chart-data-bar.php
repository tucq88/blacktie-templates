<?php

$data = array(
  array(
     'label' => 'Sales',
     'color' => '#28d8b2',
     'data'  =>
        array(
           array('Jan', 27),
           array('Feb', 82),
           array('Mar', 56),
           array('Apr', 14),
           array('May', 28),
           array('Jun', 77),
           array('Jul', 23),
           array('Aug', 49),
           array('Sep', 81),
           array('Oct', 20)
        )
    )
  );
?>