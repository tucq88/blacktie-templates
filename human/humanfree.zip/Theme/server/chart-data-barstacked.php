<?php

$data=array(
  array(
     'label' => 'Tweets',
     'color' => '#51bff2',
     'data' => 
     array(
      array('Jan', 56),
      array('Feb', 81),
      array('Mar', 97),
      array('Apr', 44),
      array('May', 24),
      array('Jun', 85),
      array('Jul', 94),
      array('Aug', 78),
      array('Sep', 52),
      array('Oct', 17),
      array('Nov', 90),
      array('Dec', 62)
    )
  ),
  array(
     'label' => 'Likes',
     'color' => '#4a8ef1',
     'data' => 
     array(
      array('Jan', 69),
      array('Feb', 135),
      array('Mar', 14),
      array('Apr', 100),
      array('May', 100),
      array('Jun', 62),
      array('Jul', 115),
      array('Aug', 22),
      array('Sep', 104),
      array('Oct', 132),
      array('Nov', 72),
      array('Dec', 61)
    )
  ),
  array(
     'label' => '+1',
     'color' => '#f0693a',
     'data' => 
     array(
      array('Jan', 29),
      array('Feb', 36),
      array('Mar', 47),
      array('Apr', 21),
      array('May', 5),
      array('Jun', 49),
      array('Jul', 37),
      array('Aug', 44),
      array('Sep', 28),
      array('Oct', 9),
      array('Nov', 12),
      array('Dec', 35)
    )
  )
);

?>